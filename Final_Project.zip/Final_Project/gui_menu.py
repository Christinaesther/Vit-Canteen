import tkinter as tk
from tkinter import messagebox
import psycopg2

# Database Connection
def connect_db():
    try:
        return psycopg2.connect(
            dbname="your_db_name",
            user="postgres",
            password="christina",
            host="localhost",
            port="5432"
        )
    except Exception as e:
        messagebox.showerror("Database Connection Error", f"Error: {e}")
        return None

# Fetch Menu Items
def fetch_menu():
    conn = connect_db()
    if not conn:
        return []
    cursor = conn.cursor()
    cursor.execute("SELECT item_id, name, price, estimated_time FROM menu")
    menu = cursor.fetchall()
    conn.close()
    return menu

menu_items = fetch_menu()
cart = []

def add_to_cart(item_id, name, price, est_time):
    cart.append({'id': item_id, 'name': name, 'price': price, 'est_time': est_time})
    update_cart_display()

def update_cart_display():
    cart_list.delete(0, tk.END)
    total = sum(item['price'] for item in cart)
    total_time = max(item['est_time'] for item in cart) if cart else 0
    
    for item in cart:
        cart_list.insert(tk.END, f"{item['name']} - ${item['price']}")
    total_label.config(text=f"Total: ${total:.2f}\nEst. Time: {total_time} min")

def remove_selected():
    try:
        index = cart_list.curselection()[0]
        cart.pop(index)
        update_cart_display()
    except IndexError:
        messagebox.showwarning("Warning", "Select an item to remove.")

def place_order():
    if not cart:
        messagebox.showwarning("Warning", "Cart is empty!")
        return
    
    conn = connect_db()
    if not conn:
        return
    cursor = conn.cursor()
    
    for item in cart:
        cursor.execute("INSERT INTO orders (item_id, quantity, total_price) VALUES (%s, %s, %s)",
                       (item['id'], 1, item['price']))
    conn.commit()
    conn.close()
    
    messagebox.showinfo("Success", "Order placed!")
    cart.clear()
    update_cart_display() 

# GUI Setup
root = tk.Tk()
root.title("Food Ordering System")
root.geometry("400x500")

menu_label = tk.Label(root, text="Menu", font=("Arial", 14, "bold"))
menu_label.pack()

menu_frame = tk.Frame(root)
menu_frame.pack()

for item in menu_items:
    btn = tk.Button(menu_frame, text=f"{item[1]} - ${item[2]}",
                    command=lambda i=item[0], n=item[1], p=item[2], c=item[3]: add_to_cart(i, n, p, c))
    btn.pack(fill=tk.X)


cart_label = tk.Label(root, text="Cart", font=("Arial", 14, "bold"))
cart_label.pack()

cart_list = tk.Listbox(root, height=8)
cart_list.pack()

total_label = tk.Label(root, text="Total: $0.00\nEst. Time: 0 min", font=("Arial", 12))
total_label.pack()

remove_btn = tk.Button(root, text="Remove Selected", command=remove_selected)
remove_btn.pack()

order_btn = tk.Button(root, text="Place Order", bg="green", fg="white", command=place_order)
order_btn.pack()

root.mainloop()