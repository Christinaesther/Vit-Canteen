document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            menuToggle.classList.toggle('active');
        });
    }

    // Close menu when clicking on a link
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', () => {
            if (navLinks) navLinks.classList.remove('active');
            if (menuToggle) menuToggle.classList.remove('active');
        });
    });

    // Profile dropdown toggle
    const profile = document.querySelector('.profile');
    const dropdown = document.querySelector('.profile-dropdown');

    if (profile && dropdown) {
        profile.addEventListener('click', (event) => {
            event.stopPropagation();
            dropdown.classList.toggle('active');
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', (event) => {
            if (!profile.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.classList.remove('active');
            }
            
            if (event.target === document.getElementById('logout-modal')) {
                closeLogoutModal();
            }
        });
    }

    // Scroll reveal animation
    const hiddenElements = document.querySelectorAll('.hidden');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('reveal');
            }
        });
    }, { threshold: 0.1 });
    
    hiddenElements.forEach(el => observer.observe(el));

    // IMPROVED: Enhanced Password toggle visibility functionality
    // First remove any existing password toggle buttons to avoid duplicates
    document.querySelectorAll('.password-toggle').forEach(btn => btn.remove());
    
    // Then add fresh password toggle buttons to all password fields
    const passwordFields = document.querySelectorAll('input[type="password"]');
    
    if (passwordFields.length > 0) {
        passwordFields.forEach(field => {
            // Create a wrapper div if the field isn't already in one
            let wrapper = field.parentElement;
            if (!wrapper.classList.contains('password-field-wrapper')) {
                wrapper = document.createElement('div');
                wrapper.className = 'password-field-wrapper';
                wrapper.style.position = 'relative';
                wrapper.style.display = 'inline-block';
                wrapper.style.width = '100%';
                field.parentNode.insertBefore(wrapper, field);
                wrapper.appendChild(field);
            }
            
            // Create toggle button with improved styling
            const toggleBtn = document.createElement('button');
            toggleBtn.type = 'button';
            toggleBtn.className = 'password-toggle';
            toggleBtn.innerHTML = '<i class="fas fa-eye"></i>';
            
            // Style the button for better visibility and positioning
            toggleBtn.style.position = 'absolute';
            toggleBtn.style.right = '10px';
            toggleBtn.style.top = '50%';
            toggleBtn.style.transform = 'translateY(-50%)';
            toggleBtn.style.background = 'none';
            toggleBtn.style.border = 'none';
            toggleBtn.style.cursor = 'pointer';
            toggleBtn.style.zIndex = '10';
            toggleBtn.style.fontSize = '16px';
            toggleBtn.style.color = '#555';
            toggleBtn.style.padding = '5px';
            
            // Add the button to the wrapper
            wrapper.appendChild(toggleBtn);
            
            // Add click event to toggle button
            toggleBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                if (field.type === 'password') {
                    field.type = 'text';
                    this.innerHTML = '<i class="fas fa-eye-slash"></i>';
                } else {
                    field.type = 'password';
                    this.innerHTML = '<i class="fas fa-eye"></i>';
                }
            });
        });
    }

    // Account form submission
    const profileForm = document.querySelector('.profile-form');
    if (profileForm) {
        const saveButton = profileForm.querySelector('button');
        if (saveButton) {
            saveButton.addEventListener('click', function(e) {
                e.preventDefault();
                // Get form data
                const formData = {
                    fullname: document.getElementById('fullname')?.value || '',
                    email: document.getElementById('email')?.value || '',
                    phone: document.getElementById('phone')?.value || '',
                    address: document.getElementById('address')?.value || ''
                };
                
                // In a real app, you would send this data to the server
                // For now, we'll just save to localStorage
                localStorage.setItem('userProfile', JSON.stringify(formData));
                
                // Show success message
                showNotification('Profile updated successfully!');
            });
        }
        
        // Load saved data if exists
        const savedProfile = localStorage.getItem('userProfile');
        if (savedProfile) {
            const profileData = JSON.parse(savedProfile);
            if (document.getElementById('fullname')) document.getElementById('fullname').value = profileData.fullname || '';
            if (document.getElementById('email')) document.getElementById('email').value = profileData.email || '';
            if (document.getElementById('phone')) document.getElementById('phone').value = profileData.phone || '';
            if (document.getElementById('address')) document.getElementById('address').value = profileData.address || '';
        }
    }

    // IMPROVED: Update password functionality with clearer message
    const updatePasswordButtons = document.querySelectorAll('.update-password, input[value="Update Password"], button[type="submit"], .settings-option button, .password-update-btn');
    
    updatePasswordButtons.forEach(button => {
        button.removeEventListener('click', handlePasswordUpdate);
        button.addEventListener('click', handlePasswordUpdate);
    });
    
    function handlePasswordUpdate(e) {
        e.preventDefault();
        
        const currentPassword = document.getElementById('current-password')?.value;
        const newPassword = document.getElementById('new-password')?.value;
        const confirmPassword = document.getElementById('confirm-password')?.value;
        
        if (!currentPassword || !newPassword || !confirmPassword) {
            showNotification('Please fill all password fields', 'error');
            return;
        }
        
        if (newPassword !== confirmPassword) {
            showNotification('New passwords do not match', 'error');
            return;
        }
        
        // Display success message specifically mentioning "Updated Password"
        showNotification('Updated Password', 'success');
        
        // Clear password fields
        if (document.getElementById('current-password')) document.getElementById('current-password').value = '';
        if (document.getElementById('new-password')) document.getElementById('new-password').value = '';
        if (document.getElementById('confirm-password')) document.getElementById('confirm-password').value = '';
    }

    // Settings functionality
    const settingsOptions = document.querySelectorAll('.settings-option');
    if (settingsOptions.length > 0) {
        // Password change (already handled by the unified handlePasswordUpdate function)
        
        // Notification preferences
        const notificationForm = settingsOptions.length > 1 ? settingsOptions[1] : null;
        const notificationButton = notificationForm?.querySelector('button');
        
        if (notificationButton) {
            notificationButton.addEventListener('click', function() {
                const emailNotifications = document.getElementById('email-notifications')?.checked;
                const smsNotifications = document.getElementById('sms-notifications')?.checked;
                const promotions = document.getElementById('promotions')?.checked;
                
                // Save preferences to localStorage
                const preferences = { 
                    emailNotifications: emailNotifications || false, 
                    smsNotifications: smsNotifications || false, 
                    promotions: promotions || false 
                };
                localStorage.setItem('notificationPreferences', JSON.stringify(preferences));
                
                showNotification('Notification preferences saved!');
            });
        }
        
        // Load saved notification preferences
        const savedPreferences = localStorage.getItem('notificationPreferences');
        if (savedPreferences) {
            const preferences = JSON.parse(savedPreferences);
            if (document.getElementById('email-notifications')) document.getElementById('email-notifications').checked = preferences.emailNotifications;
            if (document.getElementById('sms-notifications')) document.getElementById('sms-notifications').checked = preferences.smsNotifications;
            if (document.getElementById('promotions')) document.getElementById('promotions').checked = preferences.promotions;
        }
        
        // Delete account
        const deleteForm = settingsOptions.length > 2 ? settingsOptions[2] : null;
        const deleteButton = deleteForm?.querySelector('.delete-btn');
        
        if (deleteButton) {
            deleteButton.addEventListener('click', function() {
                // Show confirmation dialog
                if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
                    // In a real app, you would send a request to delete the account
                    // For now, clear local storage and redirect to login
                    localStorage.clear();
                    showNotification('Account deleted successfully');
                    
                    // Redirect to login page after 2 seconds
                    setTimeout(() => {
                        window.location.href = 'canteen (1).html';
                    }, 2000);
                }
            });
        }
    }
});

// Logout modal functions
function showLogoutModal() {
    const logoutModal = document.getElementById('logout-modal');
    if (logoutModal) logoutModal.classList.add('active');
    
    const dropdown = document.querySelector('.profile-dropdown');
    if (dropdown) dropdown.classList.remove('active');
}

function closeLogoutModal() {
    const logoutModal = document.getElementById('logout-modal');
    if (logoutModal) logoutModal.classList.remove('active');
}

function logoutUser() {
    // In a real application, this would handle the logout process
    localStorage.removeItem('userLoggedIn');
    showNotification('You have been logged out successfully!');
    
    // Redirect to login page after 1 second
    setTimeout(() => {
        window.location.href = 'canteen (1).html';
    }, 1000);
    
    closeLogoutModal();
}

// Enhanced notification function
function showNotification(message, type = 'success') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = message;
    
    // Style the notification
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.padding = '15px 20px';
    notification.style.borderRadius = '5px';
    notification.style.zIndex = '9999';
    notification.style.opacity = '0';
    notification.style.transition = 'opacity 0.3s ease';
    notification.style.fontWeight = 'bold';
    notification.style.boxShadow = '0 4px 8px rgba(0,0,0,0.2)';
    
    if (type === 'success') {
        notification.style.backgroundColor = '#4CAF50';
        notification.style.color = 'white';
    } else if (type === 'error') {
        notification.style.backgroundColor = '#F44336';
        notification.style.color = 'white';
    }
    
    // Add to page
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
        notification.style.opacity = '1';
    }, 10);
    
    // Hide and remove after 3 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => {
            if (notification.parentNode) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 3000);
}document.addEventListener('DOMContentLoaded', function() {
    // Add Font Awesome if not already present
    if (!document.querySelector('link[href*="font-awesome"]')) {
        const fontAwesome = document.createElement('link');
        fontAwesome.rel = 'stylesheet';
        fontAwesome.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css';
        document.head.appendChild(fontAwesome);
    }
    
    // Add CSS for glowing effect
    const glowStyle = document.createElement('style');
    glowStyle.textContent = `
        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            z-index: 10;
            font-size: 18px;
            padding: 5px;
            color: #777;
            transition: all 0.3s ease;
        }
        
        .password-toggle:hover {
            color: #2962ff;
            text-shadow: 0 0 5px #2962ff, 0 0 10px #2962ff;
        }
        
        .password-toggle.active {
            color: #2962ff;
            text-shadow: 0 0 5px #2962ff, 0 0 10px #2962ff, 0 0 15px #2962ff;
        }
        
        .password-field-wrapper {
            position: relative;
            display: inline-block;
            width: 100%;
        }
    `;
    document.head.appendChild(glowStyle);

    // Remove any existing password toggle buttons to avoid duplicates
    document.querySelectorAll('.password-toggle').forEach(btn => btn.remove());
    
    // Find all password fields and add toggle buttons
    const passwordFields = document.querySelectorAll('input[type="password"]');
    
    if (passwordFields.length > 0) {
        passwordFields.forEach(field => {
            // Create a wrapper if the field isn't already in one
            let wrapper = field.parentElement;
            if (!wrapper.classList.contains('password-field-wrapper')) {
                wrapper = document.createElement('div');
                wrapper.className = 'password-field-wrapper';
                field.parentNode.insertBefore(wrapper, field);
                wrapper.appendChild(field);
            }
            
            // Create toggle button with glowing effect
            const toggleBtn = document.createElement('button');
            toggleBtn.type = 'button';
            toggleBtn.className = 'password-toggle';
            toggleBtn.innerHTML = '<i class="fas fa-eye"></i>';
            
            // Add the button to the wrapper
            wrapper.appendChild(toggleBtn);
            
            // Add click event to toggle button with glowing effect
            toggleBtn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                if (field.type === 'password') {
                    field.type = 'text';
                    this.innerHTML = '<i class="fas fa-eye-slash"></i>';
                    this.classList.add('active'); // Add glow effect when password is visible
                } else {
                    field.type = 'password';
                    this.innerHTML = '<i class="fas fa-eye"></i>';
                    this.classList.remove('active'); // Remove glow effect when password is hidden
                }
            });
        });
    }

    // Update password functionality with notification
    const updatePasswordButtons = document.querySelectorAll('.update-password, input[value="Update Password"], button[type="submit"], .settings-option button, .password-update-btn');
    
    updatePasswordButtons.forEach(button => {
        button.removeEventListener('click', handlePasswordUpdate);
        button.addEventListener('click', handlePasswordUpdate);
    });
    
    function handlePasswordUpdate(e) {
        e.preventDefault();
        
        const currentPassword = document.getElementById('current-password')?.value;
        const newPassword = document.getElementById('new-password')?.value;
        const confirmPassword = document.getElementById('confirm-password')?.value;
        
        if (!currentPassword || !newPassword || !confirmPassword) {
            showNotification('Please fill all password fields', 'error');
            return;
        }
        
        if (newPassword !== confirmPassword) {
            showNotification('New passwords do not match', 'error');
            return;
        }
        
        // Display success message specifically mentioning "Updated Password"
        showNotification('Updated Password', 'success');
        
        // Clear password fields
        if (document.getElementById('current-password')) document.getElementById('current-password').value = '';
        if (document.getElementById('new-password')) document.getElementById('new-password').value = '';
        if (document.getElementById('confirm-password')) document.getElementById('confirm-password').value = '';
    }
});

// Enhanced notification function
function showNotification(message, type = 'success') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = message;
    
    // Style the notification
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.padding = '15px 20px';
    notification.style.borderRadius = '5px';
    notification.style.zIndex = '9999';
    notification.style.opacity = '0';
    notification.style.transition = 'opacity 0.3s ease';
    notification.style.fontWeight = 'bold';
    notification.style.boxShadow = '0 4px 8px rgba(0,0,0,0.2)';
    
    if (type === 'success') {
        notification.style.backgroundColor = '#4CAF50';
        notification.style.color = 'white';
    } else if (type === 'error') {
        notification.style.backgroundColor = '#F44336';
        notification.style.color = 'white';
    }
    
    // Add to page
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
        notification.style.opacity = '1';
    }, 10);
    
    // Hide and remove after 3 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => {
            if (notification.parentNode) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 3000);
}